﻿using Newtonsoft.Json;
using SunsetConsole;

bool stop = false;
var counter = 0;
while (stop == false)
{
    Console.ForegroundColor= ConsoleColor.White;
    Console.Write("Enter your State(2 Initials): ");
    var userState = Console.ReadLine();
    Console.Write("Enter your city: ");
    var userCity = Console.ReadLine();
    var country = "us";
    var filePath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.ToString() +
                Path.DirectorySeparatorChar + "data" +
                Path.DirectorySeparatorChar + "APIdata.csv";

    using (HttpClient client = new HttpClient())
    {
        string restAPILocation = "https://api.openweathermap.org/geo/1.0/direct?q=" + userCity + "," + userState + "," + country + "&limit=5&appid=c2dbe645b88e73bd3925966d5afb1ccc";

        var responseLocation = await client.GetAsync(restAPILocation);
        string jsonLocation = await responseLocation.Content.ReadAsStringAsync();

        List<CityLocation> results = JsonConvert.DeserializeObject<List<CityLocation>>(jsonLocation);

        if (results.Count > 0)
        {
            //found city
            var cityName = results[0].name;
            var stateName = results[0].state;
            var lon = results[0].lon;
            var lat = results[0].lat;

            Location location = new Location();
            location.state = stateName;
            location.name = cityName;
            location.latitude = lat.ToString();
            location.longtitude = lon.ToString();
            location.country = stateName;
            location.stationID = "TBA";
        }

        DateTime now = DateTime.Now;
        string date = now.ToString("yyyy-MM-dd");

        var responseSun = await client.GetAsync("https://api.sunrise-sunset.org/json?lat=" + results[0].lat + "&lng=" + results[0].lon + "=" + date);
        var jsonSun = await responseSun.Content.ReadAsStringAsync();

        Console.ForegroundColor = ConsoleColor.DarkGreen;
        var resultsSun = JsonConvert.DeserializeObject<SunriseSunsets>(jsonSun);
        Console.WriteLine("\n-------------------------------------------");
        Console.WriteLine($"{userCity}, {userState}");
        Console.WriteLine("-------------------------------------------");

        DateTime univDateTimeRise = DateTime.Parse(resultsSun.results.sunrise);
        DateTime localDateTimeRise = univDateTimeRise.ToLocalTime();
        Console.WriteLine($"Sunrise: {localDateTimeRise}");

        DateTime univDateTimeSet = DateTime.Parse(resultsSun.results.sunset);
        DateTime localDateTimeSet = univDateTimeSet.ToLocalTime();
        Console.WriteLine($"Sunset: {localDateTimeSet}");

        DateTime univDateTimeNoon = DateTime.Parse(resultsSun.results.solar_noon);
        DateTime localDateTimeNoon = univDateTimeNoon.ToLocalTime();
        Console.WriteLine($"Solar Noon: {localDateTimeNoon}");

        Console.WriteLine($"Day Length: {resultsSun.results.day_length}");

        DateTime univDateTimeSetBegin = DateTime.Parse(resultsSun.results.civil_twilight_begin);
        DateTime localDateTimeSetBegin = univDateTimeSetBegin.ToLocalTime();
        Console.WriteLine($"Twilight Begin: {localDateTimeSetBegin}");

        DateTime univDateTimeSetEnd = DateTime.Parse(resultsSun.results.civil_twilight_end);
        DateTime localDateTimeSetEnd = univDateTimeSetEnd.ToLocalTime();
        Console.WriteLine($"Twilight End: {localDateTimeSetEnd}");

        Console.WriteLine("-------------------------------------------");

        using (StreamWriter sr = new StreamWriter(filePath))
        {
            sr.WriteLine($"Country:{country}, City:{userCity}, State:{userState}, Date:{date}, Sunrise:{localDateTimeRise}," +
                $"Sunset:{localDateTimeSet}, SolarNoon:{localDateTimeNoon}, DayLength{resultsSun.results.day_length}," +
                $"TwilightBegin:{localDateTimeSetBegin}, TwilightEnd:{localDateTimeSetEnd}, ");
        }
        
    }
    Console.Write("Would you like another city? N to stop, anything else to continue: ");
    var answer = Console.ReadLine();
    try
    {
        if (answer.ToUpper() == "N")
        {
            stop = true;
            Console.WriteLine("\nPlease Come Again");
        }
        else if (answer.ToUpper() == "Y")
        {
            counter++;
        }
    }
    catch
    {
        Console.WriteLine("Please enter a value: Y/N");
    }
}
Console.ForegroundColor= ConsoleColor.Black;