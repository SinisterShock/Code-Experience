﻿namespace MidtermReview
{
    public enum Rating
    {
        E, 
        E10, 
        T, 
        M, 
        Ao
    }
}
